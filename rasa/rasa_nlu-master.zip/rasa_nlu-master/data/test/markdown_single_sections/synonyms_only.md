## synonym:chinese
- Chines
- Chinese
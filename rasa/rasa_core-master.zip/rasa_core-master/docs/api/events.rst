Events
======
List of all the events the dialogue system is able to handle and supports.

An event can be referenced by its ``type_name`` attribute (e.g. when returning
events in an http callback).

.. automodule:: rasa_core.events
    :members:
    :undoc-members:
    :show-inheritance:

